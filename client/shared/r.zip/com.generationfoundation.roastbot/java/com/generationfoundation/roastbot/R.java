/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.generationfoundation.roastbot;

public final class R {

    public static final class attr {
        public static final int adSize = 2130771968;
        public static final int adSizes = 2130771969;
        public static final int adUnitId = 2130771970;
        public static final int buttonSize = 2130771974;
        public static final int circleCrop = 2130771973;
        public static final int colorScheme = 2130771975;
        public static final int imageAspectRatio = 2130771972;
        public static final int imageAspectRatioAdjust = 2130771971;
        public static final int scopeUris = 2130771976;
    }

    public static final class color {
        public static final int common_google_signin_btn_text_dark = 2131034120;
        public static final int common_google_signin_btn_text_dark_default = 2131034112;
        public static final int common_google_signin_btn_text_dark_disabled = 2131034113;
        public static final int common_google_signin_btn_text_dark_focused = 2131034114;
        public static final int common_google_signin_btn_text_dark_pressed = 2131034115;
        public static final int common_google_signin_btn_text_light = 2131034121;
        public static final int common_google_signin_btn_text_light_default = 2131034116;
        public static final int common_google_signin_btn_text_light_disabled = 2131034117;
        public static final int common_google_signin_btn_text_light_focused = 2131034118;
        public static final int common_google_signin_btn_text_light_pressed = 2131034119;
    }

    public static final class drawable {
        public static final int common_full_open_on_phone = 2130837504;
        public static final int common_google_signin_btn_icon_dark = 2130837505;
        public static final int common_google_signin_btn_icon_dark_disabled = 2130837506;
        public static final int common_google_signin_btn_icon_dark_focused = 2130837507;
        public static final int common_google_signin_btn_icon_dark_normal = 2130837508;
        public static final int common_google_signin_btn_icon_dark_pressed = 2130837509;
        public static final int common_google_signin_btn_icon_light = 2130837510;
        public static final int common_google_signin_btn_icon_light_disabled = 2130837511;
        public static final int common_google_signin_btn_icon_light_focused = 2130837512;
        public static final int common_google_signin_btn_icon_light_normal = 2130837513;
        public static final int common_google_signin_btn_icon_light_pressed = 2130837514;
        public static final int common_google_signin_btn_text_dark = 2130837515;
        public static final int common_google_signin_btn_text_dark_disabled = 2130837516;
        public static final int common_google_signin_btn_text_dark_focused = 2130837517;
        public static final int common_google_signin_btn_text_dark_normal = 2130837518;
        public static final int common_google_signin_btn_text_dark_pressed = 2130837519;
        public static final int common_google_signin_btn_text_light = 2130837520;
        public static final int common_google_signin_btn_text_light_disabled = 2130837521;
        public static final int common_google_signin_btn_text_light_focused = 2130837522;
        public static final int common_google_signin_btn_text_light_normal = 2130837523;
        public static final int common_google_signin_btn_text_light_pressed = 2130837524;
        public static final int ic_action_next_item = 2130837525;
        public static final int ic_action_previous_item = 2130837526;
        public static final int ic_action_remove = 2130837527;
        public static final int icon = 2130837528;
        public static final int screen = 2130837529;
    }

    public static final class id {
        public static final int adjust_height = 2131230720;
        public static final int adjust_width = 2131230721;
        public static final int auto = 2131230726;
        public static final int dark = 2131230727;
        public static final int icon_only = 2131230723;
        public static final int light = 2131230728;
        public static final int none = 2131230722;
        public static final int standard = 2131230724;
        public static final int wide = 2131230725;
    }

    public static final class integer {
        public static final int google_play_services_version = 2131099648;
    }

    public static final class string {
        public static final int accept = 2130968576;
        public static final int activity_name = 2130968603;
        public static final int app_name = 2130968604;
        public static final int common_google_play_services_enable_button = 2130968577;
        public static final int common_google_play_services_enable_text = 2130968578;
        public static final int common_google_play_services_enable_title = 2130968579;
        public static final int common_google_play_services_install_button = 2130968580;
        public static final int common_google_play_services_install_text = 2130968581;
        public static final int common_google_play_services_install_title = 2130968582;
        public static final int common_google_play_services_notification_ticker = 2130968583;
        public static final int common_google_play_services_unknown_issue = 2130968584;
        public static final int common_google_play_services_unsupported_text = 2130968585;
        public static final int common_google_play_services_update_button = 2130968586;
        public static final int common_google_play_services_update_text = 2130968587;
        public static final int common_google_play_services_update_title = 2130968588;
        public static final int common_google_play_services_updating_text = 2130968589;
        public static final int common_google_play_services_wear_update_text = 2130968590;
        public static final int common_open_on_phone = 2130968591;
        public static final int common_signin_button_text = 2130968592;
        public static final int common_signin_button_text_long = 2130968593;
        public static final int create_calendar_message = 2130968594;
        public static final int create_calendar_title = 2130968595;
        public static final int debug_menu_ad_information = 2130968596;
        public static final int debug_menu_creative_preview = 2130968597;
        public static final int debug_menu_title = 2130968598;
        public static final int debug_menu_troubleshooting = 2130968599;
        public static final int decline = 2130968600;
        public static final int launcher_name = 2130968605;
        public static final int store_picture_message = 2130968601;
        public static final int store_picture_title = 2130968602;
    }

    public static final class style {
        public static final int Theme_IAPTheme = 2131165184;
    }

    public static final class styleable {
        public static final int[] AdsAttrs = new int[]{2130771968, 2130771969, 2130771970};
        public static final int AdsAttrs_adSize = 0;
        public static final int AdsAttrs_adSizes = 1;
        public static final int AdsAttrs_adUnitId = 2;
        public static final int[] LoadingImageView = new int[]{2130771971, 2130771972, 2130771973};
        public static final int LoadingImageView_circleCrop = 2;
        public static final int LoadingImageView_imageAspectRatio = 1;
        public static final int LoadingImageView_imageAspectRatioAdjust = 0;
        public static final int[] SignInButton = new int[]{2130771974, 2130771975, 2130771976};
        public static final int SignInButton_buttonSize = 0;
        public static final int SignInButton_colorScheme = 1;
        public static final int SignInButton_scopeUris = 2;
    }

    public static final class xml {
        public static final int config = 2130903040;
    }

}

