/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  java.lang.String
 *  org.apache.cordova.CordovaActivity
 */
package com.generationfoundation.roastbot;

import android.os.Bundle;
import org.apache.cordova.CordovaActivity;

public class MainActivity
extends CordovaActivity {
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.loadUrl(this.launchUrl);
    }
}

