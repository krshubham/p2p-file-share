/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.generationfoundation.roastbot;

public final class BuildConfig {
    public static final String APPLICATION_ID = "com.generationfoundation.roastbot";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 10006;
    public static final String VERSION_NAME = "1.0.0";
}

