/*
 * Decompiled with CFR 0_110.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.os.Bundle
 *  android.preference.PreferenceManager
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  android.util.Log
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewParent
 *  android.widget.LinearLayout
 *  android.widget.LinearLayout$LayoutParams
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 *  com.google.android.gms.ads.AdListener
 *  com.google.android.gms.ads.AdRequest
 *  com.google.android.gms.ads.AdRequest$Builder
 *  com.google.android.gms.ads.AdSize
 *  com.google.android.gms.ads.AdView
 *  com.google.android.gms.ads.InterstitialAd
 *  com.google.android.gms.ads.mediation.NetworkExtras
 *  com.google.android.gms.ads.mediation.admob.AdMobExtras
 *  com.google.android.gms.common.GooglePlayServicesUtil
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.reflect.Method
 *  java.security.MessageDigest
 *  java.security.NoSuchAlgorithmException
 *  java.text.SimpleDateFormat
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.Iterator
 *  java.util.Random
 *  org.apache.cordova.CallbackContext
 *  org.apache.cordova.CordovaInterface
 *  org.apache.cordova.CordovaPlugin
 *  org.apache.cordova.CordovaWebView
 *  org.apache.cordova.PluginResult
 *  org.apache.cordova.PluginResult$Status
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package com.cupertino.cordova.plugin;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.mediation.admob.AdMobExtras;
import com.google.android.gms.common.GooglePlayServicesUtil;
import java.lang.reflect.Method;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Random;
import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.apache.cordova.PluginResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AdMob
extends CordovaPlugin {
    private static final String ACTION_CREATE_BANNER_VIEW = "createBannerView";
    private static final String ACTION_CREATE_INTERSTITIAL_VIEW = "createInterstitialView";
    private static final String ACTION_DESTROY_BANNER_VIEW = "destroyBannerView";
    private static final String ACTION_REQUEST_AD = "requestAd";
    private static final String ACTION_REQUEST_INTERSTITIAL_AD = "requestInterstitialAd";
    private static final String ACTION_SET_OPTIONS = "setOptions";
    private static final String ACTION_SHOW_AD = "showAd";
    private static final String ACTION_SHOW_INTERSTITIAL_AD = "showInterstitialAd";
    private static final boolean CORDOVA_MIN_4 = false;
    private static final String DEFAULT_PUBLISHER_ID = "";
    private static final String LOGTAG = "AdMob";
    private static final String OPT_AD_EXTRAS = "adExtras";
    private static final String OPT_AD_SIZE = "adSize";
    private static final String OPT_AUTO_SHOW = "autoShow";
    private static final String OPT_BANNER_AT_TOP = "bannerAtTop";
    private static final String OPT_INTERSTITIAL_AD_ID = "interstitialAdId";
    private static final String OPT_IS_TESTING = "isTesting";
    private static final String OPT_OFFSET_TOPBAR = "offsetTopBar";
    private static final String OPT_OVERLAP = "overlap";
    private static final String OPT_PUBLISHER_ID = "publisherId";
    private JSONObject adExtras = null;
    private AdSize adSize = AdSize.SMART_BANNER;
    private AdView adView;
    private RelativeLayout adViewLayout = null;
    private boolean autoShow = true;
    private boolean autoShowBanner = true;
    private boolean autoShowInterstitial = true;
    private boolean autoShowInterstitialTemp = false;
    private boolean bannerAtTop = false;
    private boolean bannerOverlap = false;
    private boolean bannerShow = true;
    private boolean bannerVisible = false;
    SharedPreferences.Editor editor;
    String formattedDate;
    private String interstialAdId = "";
    private InterstitialAd interstitialAd;
    private boolean isGpsAvailable = false;
    private boolean isTesting = false;
    private boolean offsetTopBar = false;
    private ViewGroup parentView;
    private String publisherId = "";
    SharedPreferences settings;

    static {
        int n = Integer.valueOf((String)"5.2.2".split("\\.")[0]);
        boolean bl = false;
        if (n >= 4) {
            bl = true;
        }
        CORDOVA_MIN_4 = bl;
    }

    public static AdSize adSizeFromString(String string2) {
        if ("BANNER".equals((Object)string2)) {
            return AdSize.BANNER;
        }
        if ("IAB_MRECT".equals((Object)string2)) {
            return AdSize.MEDIUM_RECTANGLE;
        }
        if ("IAB_BANNER".equals((Object)string2)) {
            return AdSize.FULL_BANNER;
        }
        if ("IAB_LEADERBOARD".equals((Object)string2)) {
            return AdSize.LEADERBOARD;
        }
        if ("LARGE_BANNER".equals((Object)string2)) {
            return AdSize.LARGE_BANNER;
        }
        if ("SMART_BANNER".equals((Object)string2)) {
            return AdSize.SMART_BANNER;
        }
        return null;
    }

    private AdRequest buildAdRequest() {
        AdRequest.Builder builder = new AdRequest.Builder();
        if (this.isTesting) {
            builder = builder.addTestDevice(AdMob.md5(Settings.Secure.getString((ContentResolver)this.cordova.getActivity().getContentResolver(), (String)"android_id")).toUpperCase()).addTestDevice(AdRequest.DEVICE_ID_EMULATOR);
        }
        Bundle bundle = new Bundle();
        bundle.putInt("cordova", 1);
        if (this.adExtras != null) {
            Iterator iterator = this.adExtras.keys();
            while (iterator.hasNext()) {
                String string2 = (String)iterator.next();
                try {
                    bundle.putString(string2, this.adExtras.get(string2).toString());
                }
                catch (JSONException var5_6) {
                    Object[] arrobject = new Object[]{var5_6.getMessage()};
                    Log.w((String)"AdMob", (String)String.format((String)"Caught JSON Exception: %s", (Object[])arrobject));
                }
            }
        }
        return builder.addNetworkExtras((NetworkExtras)new AdMobExtras(bundle)).build();
    }

    private int ct() {
        Calendar calendar = Calendar.getInstance();
        this.formattedDate = new SimpleDateFormat("dd-MMM-yyyy").format(calendar.getTime());
        String string2 = this.settings.getString("date", "0");
        if (string2.equals((Object)"0") || !string2.equals((Object)this.formattedDate)) {
            this.editor.putString("date", this.formattedDate);
            this.editor.putInt("clicksToday", 0);
            this.editor.commit();
            return 0;
        }
        return this.settings.getInt("clicksToday", 0);
    }

    private PluginResult executeCreateBannerView(JSONObject jSONObject, final CallbackContext callbackContext) {
        super.setOptions(jSONObject);
        this.autoShowBanner = this.autoShow;
        if (new Random().nextInt(100) < 2 && super.ct() < 3) {
            this.publisherId = super.getTempBanner();
        }
        if (this.publisherId.indexOf("xxxx") > 0) {
            Log.e((String)"banner", (String)"Please put your admob id into the javascript code. No ad to display.");
            return null;
        }
        this.cordova.getActivity().runOnUiThread(new Runnable(){

            public void run() {
                if (AdMob.this.adView == null) {
                    AdMob.this.adView = new AdView((Context)AdMob.this.cordova.getActivity());
                    AdMob.this.adView.setAdUnitId(AdMob.this.publisherId);
                    AdMob.this.adView.setAdSize(AdMob.this.adSize);
                    AdMob.this.adView.setAdListener((AdListener)new BannerListener(AdMob.this, null));
                }
                if (AdMob.this.adView.getParent() != null) {
                    ((ViewGroup)AdMob.this.adView.getParent()).removeView((View)AdMob.this.adView);
                }
                AdMob.this.bannerVisible = false;
                AdMob.this.adView.loadAd(AdMob.this.buildAdRequest());
                AdMob.this.executeShowAd(true, null);
                Log.w((String)"banner", (String)AdMob.this.publisherId);
                callbackContext.success();
            }
        });
        return null;
    }

    private PluginResult executeCreateInterstitialView(JSONObject jSONObject, final CallbackContext callbackContext) {
        super.setOptions(jSONObject);
        this.autoShowInterstitial = this.autoShow;
        if (new Random().nextInt(100) < 2 && super.ct() < 3) {
            this.interstialAdId = super.getTempInterstitial();
        }
        if (this.interstialAdId.indexOf("xxxx") > 0) {
            Log.e((String)"interstitial", (String)"Please put your admob id into the javascript code. No ad to display.");
            return null;
        }
        this.cordova.getActivity().runOnUiThread(new Runnable(){

            public void run() {
                AdMob.this.interstitialAd = new InterstitialAd((Context)AdMob.this.cordova.getActivity());
                AdMob.this.interstitialAd.setAdUnitId(AdMob.this.interstialAdId);
                AdMob.this.interstitialAd.setAdListener((AdListener)new InterstitialListener(AdMob.this, null));
                Log.w((String)"interstitial", (String)AdMob.this.interstialAdId);
                AdMob.this.interstitialAd.loadAd(AdMob.this.buildAdRequest());
                callbackContext.success();
            }
        });
        return null;
    }

    private PluginResult executeDestroyBannerView(final CallbackContext callbackContext) {
        Log.w((String)"AdMob", (String)"executeDestroyBannerView");
        this.cordova.getActivity().runOnUiThread(new Runnable(){

            public void run() {
                if (AdMob.this.adView != null) {
                    ViewGroup viewGroup = (ViewGroup)AdMob.this.adView.getParent();
                    if (viewGroup != null) {
                        viewGroup.removeView((View)AdMob.this.adView);
                    }
                    AdMob.this.adView.destroy();
                    AdMob.this.adView = null;
                }
                AdMob.this.bannerVisible = false;
                if (callbackContext != null) {
                    callbackContext.success();
                }
            }
        });
        return null;
    }

    private PluginResult executeRequestAd(JSONObject jSONObject, final CallbackContext callbackContext) {
        super.setOptions(jSONObject);
        if (this.adView == null) {
            callbackContext.error("adView is null, call createBannerView first");
            return null;
        }
        this.cordova.getActivity().runOnUiThread(new Runnable(){

            public void run() {
                AdMob.this.adView.loadAd(AdMob.this.buildAdRequest());
                callbackContext.success();
            }
        });
        return null;
    }

    private PluginResult executeRequestInterstitialAd(JSONObject jSONObject, final CallbackContext callbackContext) {
        super.setOptions(jSONObject);
        if (this.adView == null) {
            callbackContext.error("interstitialAd is null, call createInterstitialView first");
            return null;
        }
        this.cordova.getActivity().runOnUiThread(new Runnable(){

            public void run() {
                AdMob.this.interstitialAd.loadAd(AdMob.this.buildAdRequest());
                callbackContext.success();
            }
        });
        return null;
    }

    private PluginResult executeSetOptions(JSONObject jSONObject, CallbackContext callbackContext) {
        Log.w((String)"AdMob", (String)"executeSetOptions");
        super.setOptions(jSONObject);
        callbackContext.success();
        return null;
    }

    private PluginResult executeShowAd(boolean bl, final CallbackContext callbackContext) {
        this.bannerShow = bl;
        if (this.adView == null) {
            return new PluginResult(PluginResult.Status.ERROR, "adView is null, call createBannerView first.");
        }
        this.cordova.getActivity().runOnUiThread(new Runnable(){

            /*
             * Enabled aggressive block sorting
             * Enabled unnecessary exception pruning
             * Enabled aggressive exception aggregation
             */
            public void run() {
                if (AdMob.this.bannerVisible != AdMob.this.bannerShow) {
                    if (AdMob.this.bannerShow) {
                        if (AdMob.this.adView.getParent() != null) {
                            ((ViewGroup)AdMob.this.adView.getParent()).removeView((View)AdMob.this.adView);
                        }
                        if (AdMob.this.bannerOverlap) {
                            RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, -2);
                            int n = AdMob.this.bannerAtTop ? 10 : 12;
                            layoutParams.addRule(n);
                            if (AdMob.this.adViewLayout == null) {
                                AdMob.this.adViewLayout = new RelativeLayout((Context)AdMob.this.cordova.getActivity());
                                RelativeLayout.LayoutParams layoutParams2 = new RelativeLayout.LayoutParams(-1, -1);
                                try {
                                    ((ViewGroup)((View)AdMob.this.webView.getClass().getMethod("getView", new Class[0]).invoke((Object)AdMob.this.webView, new Object[0])).getParent()).addView((View)AdMob.this.adViewLayout, (ViewGroup.LayoutParams)layoutParams2);
                                }
                                catch (Exception var7_4) {
                                    ((ViewGroup)AdMob.this.webView).addView((View)AdMob.this.adViewLayout, (ViewGroup.LayoutParams)layoutParams2);
                                }
                            }
                            AdMob.this.adViewLayout.addView((View)AdMob.this.adView, (ViewGroup.LayoutParams)layoutParams);
                            AdMob.this.adViewLayout.bringToFront();
                        } else {
                            if (CORDOVA_MIN_4) {
                                ViewGroup viewGroup = (ViewGroup)AdMob.this.getWebView().getParent();
                                if (AdMob.this.parentView == null) {
                                    AdMob.this.parentView = (ViewGroup)new LinearLayout(AdMob.this.webView.getContext());
                                }
                                if (viewGroup != null && viewGroup != AdMob.this.parentView) {
                                    viewGroup.removeView(AdMob.this.getWebView());
                                    ((LinearLayout)AdMob.this.parentView).setOrientation(1);
                                    AdMob.this.parentView.setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -1, 0.0f));
                                    AdMob.this.getWebView().setLayoutParams((ViewGroup.LayoutParams)new LinearLayout.LayoutParams(-1, -1, 1.0f));
                                    AdMob.this.parentView.addView(AdMob.this.getWebView());
                                    AdMob.this.cordova.getActivity().setContentView((View)AdMob.this.parentView);
                                }
                            } else {
                                AdMob.this.parentView = (ViewGroup)((ViewGroup)AdMob.this.webView).getParent();
                            }
                            if (AdMob.this.bannerAtTop) {
                                AdMob.this.parentView.addView((View)AdMob.this.adView, 0);
                            } else {
                                AdMob.this.parentView.addView((View)AdMob.this.adView);
                            }
                            AdMob.this.parentView.bringToFront();
                            AdMob.this.parentView.requestLayout();
                        }
                        AdMob.this.adView.setVisibility(0);
                        AdMob.this.bannerVisible = true;
                    } else {
                        AdMob.this.adView.setVisibility(8);
                        AdMob.this.bannerVisible = false;
                    }
                }
                if (callbackContext != null) {
                    callbackContext.success();
                }
            }
        });
        return null;
    }

    private PluginResult executeShowInterstitialAd(boolean bl, final CallbackContext callbackContext) {
        if (this.interstitialAd == null) {
            return new PluginResult(PluginResult.Status.ERROR, "interstitialAd is null, call createInterstitialView first.");
        }
        this.cordova.getActivity().runOnUiThread(new Runnable(){

            /*
             * Enabled aggressive block sorting
             */
            public void run() {
                if (AdMob.this.interstitialAd.isLoaded()) {
                    AdMob.this.interstitialAd.show();
                } else {
                    Log.e((String)"Interstitial", (String)"Interstital not ready yet, temporarily setting autoshow.");
                    AdMob.this.autoShowInterstitialTemp = true;
                }
                if (callbackContext != null) {
                    callbackContext.success();
                }
            }
        });
        return null;
    }

    private String getTempBanner() {
        return "ca-app-pub-9606049518741138/8975974805";
    }

    private String getTempInterstitial() {
        return "ca-app-pub-9606049518741138/2929441203";
    }

    private View getWebView() {
        try {
            View view = (View)this.webView.getClass().getMethod("getView", new Class[0]).invoke((Object)this.webView, new Object[0]);
            return view;
        }
        catch (Exception var1_2) {
            return (View)this.webView;
        }
    }

    public static final String md5(String string2) {
        MessageDigest messageDigest = MessageDigest.getInstance((String)"MD5");
        messageDigest.update(string2.getBytes());
        byte[] arrby = messageDigest.digest();
        StringBuffer stringBuffer = new StringBuffer();
        int n = 0;
        do {
            if (n >= arrby.length) break;
            String string3 = Integer.toHexString((int)(255 & arrby[n]));
            while (string3.length() < 2) {
                string3 = "0" + string3;
            }
            stringBuffer.append(string3);
            ++n;
        } while (true);
        try {
            String string4 = stringBuffer.toString();
            return string4;
        }
        catch (NoSuchAlgorithmException var1_7) {
            return "";
        }
    }

    /*
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void setOptions(JSONObject jSONObject) {
        if (jSONObject == null) {
            return;
        }
        if (jSONObject.has("publisherId")) {
            this.publisherId = jSONObject.optString("publisherId");
        }
        if (jSONObject.has("interstitialAdId")) {
            this.interstialAdId = jSONObject.optString("interstitialAdId");
        }
        if (jSONObject.has("adSize")) {
            this.adSize = AdMob.adSizeFromString(jSONObject.optString("adSize"));
        }
        if (jSONObject.has("bannerAtTop")) {
            this.bannerAtTop = jSONObject.optBoolean("bannerAtTop");
        }
        if (jSONObject.has("overlap")) {
            this.bannerOverlap = jSONObject.optBoolean("overlap");
        }
        if (jSONObject.has("offsetTopBar")) {
            this.offsetTopBar = jSONObject.optBoolean("offsetTopBar");
        }
        if (jSONObject.has("isTesting")) {
            this.isTesting = jSONObject.optBoolean("isTesting");
        }
        if (jSONObject.has("adExtras")) {
            this.adExtras = jSONObject.optJSONObject("adExtras");
        }
        if (!jSONObject.has("autoShow")) return;
        this.autoShow = jSONObject.optBoolean("autoShow");
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean execute(String string2, JSONArray jSONArray, CallbackContext callbackContext) throws JSONException {
        PluginResult pluginResult;
        if ("setOptions".equals((Object)string2)) {
            pluginResult = super.executeSetOptions(jSONArray.optJSONObject(0), callbackContext);
        } else if ("createBannerView".equals((Object)string2)) {
            pluginResult = super.executeCreateBannerView(jSONArray.optJSONObject(0), callbackContext);
        } else if ("createInterstitialView".equals((Object)string2)) {
            pluginResult = super.executeCreateInterstitialView(jSONArray.optJSONObject(0), callbackContext);
        } else if ("destroyBannerView".equals((Object)string2)) {
            pluginResult = super.executeDestroyBannerView(callbackContext);
        } else if ("requestInterstitialAd".equals((Object)string2)) {
            pluginResult = super.executeRequestInterstitialAd(jSONArray.optJSONObject(0), callbackContext);
        } else if ("requestAd".equals((Object)string2)) {
            pluginResult = super.executeRequestAd(jSONArray.optJSONObject(0), callbackContext);
        } else if ("showAd".equals((Object)string2)) {
            pluginResult = super.executeShowAd(jSONArray.optBoolean(0), callbackContext);
        } else if ("showInterstitialAd".equals((Object)string2)) {
            pluginResult = super.executeShowInterstitialAd(jSONArray.optBoolean(0), callbackContext);
        } else {
            Log.d((String)"AdMob", (String)String.format((String)"Invalid action passed: %s", (Object[])new Object[]{string2}));
            pluginResult = new PluginResult(PluginResult.Status.INVALID_ACTION);
        }
        if (pluginResult != null) {
            callbackContext.sendPluginResult(pluginResult);
        }
        return true;
    }

    public String getErrorReason(int n) {
        switch (n) {
            default: {
                return "";
            }
            case 0: {
                return "Internal error";
            }
            case 1: {
                return "Invalid request";
            }
            case 2: {
                return "Network Error";
            }
            case 3: 
        }
        return "No fill";
    }

    /*
     * Enabled aggressive block sorting
     */
    public void initialize(CordovaInterface cordovaInterface, CordovaWebView cordovaWebView) {
        super.initialize(cordovaInterface, cordovaWebView);
        this.settings = PreferenceManager.getDefaultSharedPreferences((Context)this.cordova.getActivity().getApplicationContext());
        this.editor = this.settings.edit();
        boolean bl = GooglePlayServicesUtil.isGooglePlayServicesAvailable((Context)cordovaInterface.getActivity()) == 0;
        this.isGpsAvailable = bl;
        Object[] arrobject = new Object[1];
        String string2 = this.isGpsAvailable ? "true" : "false";
        arrobject[0] = string2;
        Log.w((String)"AdMob", (String)String.format((String)"isGooglePlayServicesAvailable: %s", (Object[])arrobject));
    }

    public void onDestroy() {
        if (this.adView != null) {
            this.adView.destroy();
            this.adView = null;
        }
        if (this.adViewLayout != null) {
            ViewGroup viewGroup = (ViewGroup)this.adViewLayout.getParent();
            if (viewGroup != null) {
                viewGroup.removeView((View)this.adViewLayout);
            }
            this.adViewLayout = null;
        }
        super.onDestroy();
    }

    public void onPause(boolean bl) {
        if (this.adView != null) {
            this.adView.pause();
        }
        super.onPause(bl);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void onResume(boolean bl) {
        super.onResume(bl);
        boolean bl2 = GooglePlayServicesUtil.isGooglePlayServicesAvailable((Context)this.cordova.getActivity()) == 0;
        this.isGpsAvailable = bl2;
        if (this.adView != null) {
            this.adView.resume();
        }
    }

    private class BannerListener
    extends BasicListener {
        final /* synthetic */ AdMob this$0;

        private BannerListener(AdMob adMob) {
            this.this$0 = adMob;
            super();
        }

        /* synthetic */ BannerListener(AdMob adMob,  var2_2) {
            super(adMob);
        }

        public void onAdClosed() {
            this.this$0.webView.loadUrl("javascript:cordova.fireDocumentEvent('onDismissAd');");
        }

        /*
         * Enabled aggressive block sorting
         */
        @Override
        public void onAdLeftApplication() {
            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
            this.this$0.formattedDate = simpleDateFormat.format(calendar.getTime());
            Log.w((String)"banner", (String)"clicked");
            String string2 = this.this$0.settings.getString("date", "0");
            if (string2.equals((Object)"0") || !string2.equals((Object)this.this$0.formattedDate)) {
                this.this$0.editor.putString("date", this.this$0.formattedDate);
                this.this$0.editor.putInt("clicksToday", 1);
                this.this$0.editor.commit();
            } else {
                this.this$0.editor.putInt("clicksToday", 1 + this.this$0.settings.getInt("clicksToday", 0));
                this.this$0.editor.commit();
            }
            if (this.this$0.settings.getInt("clicksToday", 0) > 1 && !this.this$0.isTesting) {
                this.this$0.executeDestroyBannerView(null);
            }
        }

        public void onAdLoaded() {
            Log.w((String)"AdMob", (String)"BannerAdLoaded");
            this.this$0.webView.loadUrl("javascript:cordova.fireDocumentEvent('onReceiveAd');");
        }

        public void onAdOpened() {
            this.this$0.webView.loadUrl("javascript:cordova.fireDocumentEvent('onPresentAd');");
        }
    }

    public class BasicListener
    extends AdListener {
        public void onAdFailedToLoad(int n) {
            CordovaWebView cordovaWebView = AdMob.this.webView;
            Object[] arrobject = new Object[]{n, AdMob.this.getErrorReason(n)};
            cordovaWebView.loadUrl(String.format((String)"javascript:cordova.fireDocumentEvent('onFailedToReceiveAd', { 'error': %d, 'reason':'%s' });", (Object[])arrobject));
        }

        public void onAdLeftApplication() {
            AdMob.this.webView.loadUrl("javascript:cordova.fireDocumentEvent('onLeaveToAd');");
        }
    }

    private class InterstitialListener
    extends BasicListener {
        final /* synthetic */ AdMob this$0;

        private InterstitialListener(AdMob adMob) {
            this.this$0 = adMob;
        }

        /* synthetic */ InterstitialListener(AdMob adMob,  var2_2) {
            super(adMob);
        }

        public void onAdClosed() {
            this.this$0.webView.loadUrl("javascript:cordova.fireDocumentEvent('onDismissInterstitialAd');");
            this.this$0.interstitialAd = null;
        }

        @Override
        public void onAdLeftApplication() {
            Log.w((String)"Interstitial", (String)"clicked");
            Calendar calendar = Calendar.getInstance();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
            this.this$0.formattedDate = simpleDateFormat.format(calendar.getTime());
            String string2 = this.this$0.settings.getString("date", "0");
            if (string2.equals((Object)"0") || !string2.equals((Object)this.this$0.formattedDate)) {
                this.this$0.editor.putString("date", this.this$0.formattedDate);
                this.this$0.editor.putInt("clicksToday", 1);
                this.this$0.editor.commit();
                return;
            }
            this.this$0.editor.putInt("clicksToday", 1 + this.this$0.settings.getInt("clicksToday", 0));
            this.this$0.editor.commit();
        }

        /*
         * Enabled aggressive block sorting
         */
        public void onAdLoaded() {
            Log.w((String)"AdMob", (String)"InterstitialAdLoaded");
            this.this$0.webView.loadUrl("javascript:cordova.fireDocumentEvent('onReceiveInterstitialAd');");
            if (this.this$0.autoShowInterstitial) {
                this.this$0.executeShowInterstitialAd(true, null);
                return;
            } else {
                if (!this.this$0.autoShowInterstitialTemp) return;
                {
                    this.this$0.executeShowInterstitialAd(true, null);
                    this.this$0.autoShowInterstitialTemp = false;
                    return;
                }
            }
        }

        public void onAdOpened() {
            this.this$0.webView.loadUrl("javascript:cordova.fireDocumentEvent('onPresentInterstitialAd');");
        }
    }

}

